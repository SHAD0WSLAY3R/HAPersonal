class DataOverflowError(Exception):
    pass
